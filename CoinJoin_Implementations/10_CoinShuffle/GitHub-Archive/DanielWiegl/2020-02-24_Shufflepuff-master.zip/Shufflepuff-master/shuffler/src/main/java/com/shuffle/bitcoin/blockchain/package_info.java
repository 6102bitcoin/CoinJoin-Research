/**
 *
 * Copyright © 2016 Mycelium.
 * Use of this source code is governed by an ISC
 * license that can be found in the LICENSE file.
 *
 * Blockchain provides for implementations of Coin using bitcoinj with options for different
 * methods of accessing the blockchain.
 *
 */
package com.shuffle.bitcoin.blockchain;
