/**
 *
 * Copyright © 2016 Mycelium.
 * Use of this source code is governed by an ISC
 * license that can be found in the LICENSE file.
 *
 */

package com.shuffle.moderator;

/**
 * TODO The client side to the Moderator.
 *
 * Created by Daniel Krawisz on 1/26/16.
 */
public class Client {
}
