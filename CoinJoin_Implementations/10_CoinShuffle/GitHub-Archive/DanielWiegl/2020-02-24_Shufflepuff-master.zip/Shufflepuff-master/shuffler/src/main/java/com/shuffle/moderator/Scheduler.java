/**
 *
 * Copyright © 2016 Mycelium.
 * Use of this source code is governed by an ISC
 * license that can be found in the LICENSE file.
 *
 */

package com.shuffle.moderator;

/**
 * REST API:
 *
 * Created by Daniel Krawisz on 12/25/15.
 */
public class Scheduler {

    // TODO
    public Mixes getMix(String session) {
        return null;
    }

    // TODO
    public Mixes create() {
        return null;
    }
}
