/**
 *
 * Copyright © 2016 Mycelium.
 * Use of this source code is governed by an ISC
 * license that can be found in the LICENSE file.
 * The moderator package provides for a service that keeps track of pending mixes and attempts
 * to contact the parties and get the mix started once it is ready.
 *
 * Created by Daniel Krawisz on 12/26/15.
 */
package com.shuffle.moderator;
