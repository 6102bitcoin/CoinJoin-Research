/**
 *
 * Copyright © 2016 Mycelium.
 * Use of this source code is governed by an ISC
 * license that can be found in the LICENSE file.
 *
 */

package com.shuffle.p2p;

import com.shuffle.chan.Send;

import java.io.IOException;
import java.io.Serializable;

/**
 * An implementation of Peer which is good for implementations which do not contain
 * other Peer objects, ie, they are fundamental. For example, it is used in TcpChannel and
 * the websocket channels.
 *
 * Created by Daniel Krawisz on 3/18/16.
 */
public abstract class FundamentalPeer<Identity, Message extends Serializable> implements Peer<Identity, Message> {
    private final Identity you;
    protected Session<Identity, Message> currentSession = null;

    protected FundamentalPeer(Identity you) {
        this.you = you;
    }

    public final Identity identity() {
        return you;
    }

    // Returns null if there is a session already open.
    public abstract Session<Identity, Message> openSession(Send<Message> send)
            throws InterruptedException, IOException;

    // Whether there is an open session to this peer.
    public final boolean open() throws InterruptedException {
        return currentSession != null && !currentSession.closed();
    }

    // Close any open sessions for this peer.
    public final void close() {
        if (currentSession != null) {
            currentSession.close();
        }
        currentSession = null;
    }

    @Override
    public int hashCode() {
        return you.hashCode() * 17;
    }
}
