/**
 *
 * Copyright © 2016 Mycelium.
 * Use of this source code is governed by an ISC
 * license that can be found in the LICENSE file.
 *
 * Package player provides for a full implementation of CoinShuffle capable of running
 * on its own as a standalone application or as a component to another application, either
 *
 *
 * Created by Daniel Krawisz on 1/25/16.
 *
 *
 */
package com.shuffle.player;
