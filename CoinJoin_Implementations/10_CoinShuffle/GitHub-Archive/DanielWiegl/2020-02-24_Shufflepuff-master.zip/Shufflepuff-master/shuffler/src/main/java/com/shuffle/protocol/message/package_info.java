/**
 *
 * Copyright © 2016 Mycelium.
 * Use of this source code is governed by an ISC
 * license that can be found in the LICENSE file.
 *
 * Package message contains interfaces used to define the message formats of CoinShuffle.
 *
 *
 * Created by Daniel Krawisz on 4/11/16.
 *
 *
 */
package com.shuffle.protocol.message;
