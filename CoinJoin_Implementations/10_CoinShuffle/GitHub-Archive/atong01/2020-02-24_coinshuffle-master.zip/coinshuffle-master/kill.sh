pkill -f 'python client.py'
pkill -f 'python shuffle_server.py'
