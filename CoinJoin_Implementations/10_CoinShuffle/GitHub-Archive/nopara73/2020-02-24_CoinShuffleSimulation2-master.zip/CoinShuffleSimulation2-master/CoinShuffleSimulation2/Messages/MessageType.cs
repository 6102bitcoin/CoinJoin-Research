﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoinShuffleSimulation2.Messages
{
    public enum MessageType
    {
        PublicKey,
        Onions,
        ShuffledScripts
    }
}
