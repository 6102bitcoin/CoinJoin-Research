See Releases: https://github.com/zksnacks/wabisabi/releases
